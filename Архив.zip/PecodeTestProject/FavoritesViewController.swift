//
//  FavoritesViewController.swift
//  PecodeTestProject
//
//  Created by Dmitriy Ponomarenko on 25.01.2022.
//

import UIKit

class FavoritesViewController: UIViewController, UITabBarDelegate, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var favoriteTableView: UITableView!
    var articlesDataSource = [Article]()
    init(dataSource: [Article]) {
        self.articlesDataSource = dataSource
        super.init(nibName: "FavoritesViewController", bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        favoriteTableView.delegate = self
        favoriteTableView.dataSource = self
        favoriteTableView.register(UINib.init(nibName: "CustomTableViewCell", bundle: nil), forCellReuseIdentifier: "favoriteReuseIdentifier")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return articlesDataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: CustomTableViewCell = tableView.dequeueReusableCell(withIdentifier: "favoriteReuseIdentifier", for: indexPath) as! CustomTableViewCell
        let articleForCell = articlesDataSource[indexPath.row]
        cell.isFavorite = true
        cell.setupWith(articleForCell, index: indexPath.row)
        return cell
    }
}
