//
//  NetworkManager.swift
//  PecodeTestProject
//
//  Created by Yaroslav Shepilov on 24.01.2022.
//

import Foundation

struct NetworkManager {
    func getArticles(completion: @escaping (Result<[Article], Error>) -> ()) {
        var components = URLComponents()
        components.scheme = "https"
        components.host = "newsapi.org"
        components.path = "/v2/everything"
        components.queryItems = [URLQueryItem(name: "sort_by", value: "popularity"),
                                 URLQueryItem(name: "apiKey", value: "1c1fc3443f2644468db108be0495404a"),
                                 URLQueryItem(name: "q", value: "Apple"),
                                 URLQueryItem(name: "from", value: "2022-01-24")]

    guard let url = components.url else { return }
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "GET"
        let session = URLSession(configuration: .default)
        let dataTask = session.dataTask(with: urlRequest) { data, response, error in
            if let err = error {
                completion(.failure(err))
                print(err.localizedDescription)
                return
            }
            guard response != nil, let data = data else {
                return
            }
            guard let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else {
              return
            }
            guard let theJSONData = try? JSONSerialization.data(withJSONObject: json["articles"], options: .prettyPrinted) else { return }
            guard let networkArticles = try? JSONDecoder().decode([ArticlesNetwork].self, from: theJSONData) else { return }
            let articles = networkArticles.map {map(from:$0)}
            DispatchQueue.main.async {
                completion(.success(articles))
            }
        }
        dataTask.resume()
    }
    func map(from: ArticlesNetwork) -> Article {
        return Article( source: from.source, author: from.author, title: from.title, description: from.description, url: from.url, urlToImage: from.urlToImage, publishedAt:from.publishedAt, content: from.content, isSelected: false)
    }
}

struct Article: Codable {
    let source: Source
    let author: String?
    let title: String
    let description: String
    let url: String
    let urlToImage: String
    let publishedAt: String
    let content: String
    var isSelected: Bool = false
}

struct ArticlesNetwork: Codable {
    let source: Source
    let author: String?
    let title: String
    let description: String
    let url: String
    let urlToImage: String
    let publishedAt: String
    let content: String
}

struct Source: Codable {
    let id: String?
    let name: String
}

