//
//  CustomTableViewCell.swift
//  PecodeTestProject
//
//  Created by Dmitriy Ponomarenko on 25.01.2022.
//

import UIKit
protocol CustomTableViewCellDelegate {
    func didAddToFavorite(index: Int)
}

class CustomTableViewCell: UITableViewCell {

    @IBOutlet weak var newsTitleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var sourceLabel: UILabel!
    @IBOutlet weak var addToFavoriteButton: UIButton!
    @IBOutlet weak var newsImageView: UIImageView!
    
    private var index: Int?
    var delegate: CustomTableViewCellDelegate?
    var isFavorite: Bool = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setupWith(_ article: Article, index: Int) {
        self.index = index
        newsTitleLabel.text = article.title
        authorLabel.text = article.author
        descriptionLabel.text = article.description
        sourceLabel.text = "source - \(article.source.name)"
        if isFavorite {
            addToFavoriteButton.isHidden = true } else {
            addToFavoriteButton.isHidden = false
            if article.isSelected {
                accessoryType = .checkmark
            } else {
                accessoryType = .none
            }
        }
        
        let urlString = article.urlToImage
        guard let url = URL(string: urlString) else {return}
        newsImageView.downloaded(from: url)
    }
    
    @IBAction func addToFavoriteButton(_ sender: UIButton) {
        guard let index = index else { return }
        delegate?.didAddToFavorite(index: index)
    }
}

extension UIImageView {
    func downloaded(from url: URL, contentMode mode: ContentMode = .scaleAspectFill) {
        DispatchQueue.global().async {
            URLSession.shared.dataTask(with: url) { data, response, error in
                guard
                    let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                    let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                    let data = data, error == nil,
                    let image = UIImage(data: data)
                else { return }
                DispatchQueue.main.async { [weak self] in
                    self?.image = image
                    self?.contentMode = mode
                }
            }.resume()
        }
    }
    
    func downloaded(from link: String, contentMode mode: ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
}
