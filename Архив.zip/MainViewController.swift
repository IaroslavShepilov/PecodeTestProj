//
//  MainViewController.swift
//  PecodeTestProject
//
//  Created by Dmitriy Ponomarenko on 25.01.2022.
//

import UIKit

class MainViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchResultsUpdating {
    
    let networkManager = NetworkManager()
    let searchController = UISearchController()
    var articlesDataSource = [Article]()
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        setupFavoriteButton()
        downloadArticles()
    }
    
    func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib.init(nibName: "CustomTableViewCell", bundle: nil), forCellReuseIdentifier: "reuseIdentifier")
        tableView.estimatedRowHeight = 500
        tableView.rowHeight = UITableView.automaticDimension
        tableView.refreshControl = UIRefreshControl()
        tableView.refreshControl?.addTarget(self, action: #selector(didPullRefresh), for: .valueChanged)
        searchController.searchResultsUpdater = self
        navigationItem.searchController = searchController
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        guard let text = searchController.searchBar.text else { return }
        print(text)
    }
    
    @objc func didPullRefresh() {
        DispatchQueue.main.async {
            self.tableView.refreshControl?.endRefreshing()
        }
    }
    
    func setupFavoriteButton() {
        self.title = "News"
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Favorites", style: .plain, target: self, action: #selector(onFavoriteTapped))
    }
    
    func downloadArticles() {
        networkManager.getArticles(completion: { [weak self] (result: Result<[Article], Error>) in
            switch result {
            case .success(let article):
                self?.articlesDataSource = article
                DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        })
    }
    
    @objc func onFavoriteTapped() {
        let filteredArticle = articlesDataSource.filter { $0.isSelected == true }
        navigationController?.pushViewController(FavoritesViewController(dataSource: filteredArticle), animated: true)
    }

    // MARK: - Table view data source
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return articlesDataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: CustomTableViewCell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath) as! CustomTableViewCell
        let articleForCell = articlesDataSource[indexPath.row]
        cell.setupWith(articleForCell, index: indexPath.row)
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let articleForCell = articlesDataSource[indexPath.row]
        guard let url = URL(string: articleForCell.url) else {return}
        let vc = DetailsViewController(url: url, title: articleForCell.title)
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension MainViewController: CustomTableViewCellDelegate {
    func didAddToFavorite(index: Int) {
        articlesDataSource[index].isSelected = !articlesDataSource[index].isSelected
        tableView.reloadData()
    }
}
